from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import uvicorn
from fastapi import FastAPI, Request, status
from starlette.middleware import Middleware
from starlette.middleware.sessions import SessionMiddleware
from app.routers import templates, static_files, router, api_router
from app.config import get_settings
from contextlib import asynccontextmanager


# Load settings once
settings = get_settings()

# Initialize templates and static files
templates = Jinja2Templates(directory="app/templates")
static_files = StaticFiles(directory="app/static")

# Lifespan to initialize database
@asynccontextmanager
async def lifespan(app: FastAPI):
    from app.database import create_db_and_tables
    create_db_and_tables()
    yield

# Create FastAPI app
app = FastAPI(
    middleware=[Middleware(SessionMiddleware, secret_key=settings.secret_key)],
    lifespan=lifespan
)

# Include routers
app.include_router(router)
app.include_router(api_router)
app.mount("/static", static_files, name="static")

# Exception handler
@app.exception_handler(status.HTTP_401_UNAUTHORIZED)
async def unauthorized_redirect_handler(request: Request, exc: Exception):
    return templates.TemplateResponse(
        name="401.html",
        context={"request": request}
    )

# Run with uvicorn
if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host=settings.app_host if hasattr(settings, "app_host") else "127.0.0.1",
        port=settings.app_port if hasattr(settings, "app_port") else 8000,
        reload=settings.env.lower() != "production"
    )